# 9 practical Databricks custom container use cases with tiny examples

## 1. Golden runtime for regulated environments

A custom container can act as an approved runtime image: labelled, built in CI, scanned, and reused across environments.

```dockerfile
FROM databricksruntime/standard:16.4-LTS

LABEL owner="data-platform"
LABEL purpose="approved-databricks-runtime-demo"
LABEL version="2026.05.27"
```

Tiny smoke test in Databricks:

```bash
%sh
cat /opt/demo/hello.txt
which duckdb
which dqcheck
```

## 2. Run a native executable next to Spark

DuckDB is a good demo because it is a native executable, not just a Python package.

```dockerfile
ARG DUCKDB_VERSION=1.4.4

RUN curl -L \
  "https://github.com/duckdb/duckdb/releases/download/v${DUCKDB_VERSION}/duckdb_cli-linux-amd64.zip" \
  -o /tmp/duckdb.zip \
  && unzip /tmp/duckdb.zip -d /usr/local/bin \
  && chmod +x /usr/local/bin/duckdb \
  && rm /tmp/duckdb.zip
```

Notebook test:

```bash
%sh
duckdb -c "select 42 as answer, current_date as run_date;"
```

## 3. Use DuckDB to inspect files written by Spark

Spark writes the data:

```python
df.write.mode("overwrite").parquet("file:/tmp/duckdb_demo/orders")
```

DuckDB inspects it:

```bash
%sh
duckdb -c "
select country, count(*) as rows, sum(amount) as total_amount
from read_parquet('/tmp/duckdb_demo/orders/*.parquet')
group by country
order by country;
"
```

## 4. Offline or restricted network environments

In restricted environments, clusters should not download random packages at runtime. The approved image already contains the tools.

```dockerfile
RUN apt-get update && apt-get install -y --no-install-recommends \
    jq \
    ripgrep \
    ca-certificates \
    && rm -rf /var/lib/apt/lists/*
```

Notebook test:

```bash
%sh
jq --version
rg --version | head -1
```

## 5. CI/CD for the runtime, not only the code

The runtime image can be built, tagged, scanned, and promoted like application code.

```bash
docker buildx build \
  --platform linux/amd64 \
  -t hdudek/dbx-custom-container-fakers:2026.05.27 \
  --load .
```

```bash
docker push hdudek/dbx-custom-container-fakers:2026.05.27
```

## 6. Legacy system integration

Many enterprise pipelines still depend on command-line tools, vendor utilities, or small internal binaries.

```dockerfile
COPY bin/dqcheck /usr/local/bin/dqcheck
RUN chmod +x /usr/local/bin/dqcheck
```

Notebook test:

```bash
%sh
dqcheck scan --input /tmp/duckdb_demo/orders --output /tmp/dq_report.json
cat /tmp/dq_report.json | jq .
```

Spark can read the report:

```python
report = spark.read.json("file:/tmp/dq_report.json")
display(report)
```

## 7. Add enterprise certificates once

Certificates are runtime dependencies, not notebook logic.

```dockerfile
COPY certs/company-root-ca.crt /usr/local/share/ca-certificates/company-root-ca.crt
RUN update-ca-certificates
```

Notebook test:

```bash
%sh
ls -l /usr/local/share/ca-certificates/company-root-ca.crt
grep -n "BEGIN CERTIFICATE" /usr/local/share/ca-certificates/company-root-ca.crt
```

## 8. Internal packages and private wheels

A custom container can carry an approved internal package version.

```dockerfile
COPY dist/company_quality_rules-0.1.0-py3-none-any.whl /opt/wheels/
RUN /databricks/python3/bin/pip install --no-cache-dir \
    /opt/wheels/company_quality_rules-0.1.0-py3-none-any.whl
```

Notebook test:

```python
from company_quality_rules import validate_table_name

validate_table_name("customer_orders")
```

## 9. Enterprise database drivers / client tools

The container should carry the client runtime, not credentials.

```dockerfile
RUN apt-get update && apt-get install -y --no-install-recommends \
    postgresql-client \
    unixodbc \
    && rm -rf /var/lib/apt/lists/*
```

Notebook test:

```bash
%sh
psql --version
```

## Closing line

Custom containers are not only about installing dependencies. They are about making the Databricks runtime itself reproducible, testable, and governed.
