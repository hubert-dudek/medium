# Databricks custom container smoke tests
# Copy these cells into a Databricks notebook attached to dedicated compute using the custom image.

# COMMAND ----------

# MAGIC %sh
# MAGIC echo "1. Golden runtime smoke test"
# MAGIC cat /opt/demo/hello.txt
# MAGIC echo
# MAGIC echo "Image labels are not always visible from inside the container, so we test installed runtime assets instead:"
# MAGIC which duckdb
# MAGIC which dqcheck
# MAGIC which psql

# COMMAND ----------

# MAGIC %sh
# MAGIC echo "2. Native executable next to Spark: DuckDB"
# MAGIC duckdb --version
# MAGIC duckdb -c "select 42 as answer, current_date as run_date;"

# COMMAND ----------

from pyspark.sql import functions as F

df = spark.createDataFrame(
    [
        (1, "Alice", "PL", 100.0),
        (2, "Bob", "CZ", 150.0),
        (3, "Carla", "IT", 200.0),
        (4, "Daniel", "PL", 120.0),
    ],
    ["id", "name", "country", "amount"],
)

df.write.mode("overwrite").parquet("file:/tmp/duckdb_demo/orders")
display(df)

# COMMAND ----------

# MAGIC %sh
# MAGIC echo "3. DuckDB inspecting files written by Spark"
# MAGIC duckdb -c "
# MAGIC select
# MAGIC   country,
# MAGIC   count(*) as rows,
# MAGIC   sum(amount) as total_amount
# MAGIC from read_parquet('/tmp/duckdb_demo/orders/*.parquet')
# MAGIC group by country
# MAGIC order by country;
# MAGIC "

# COMMAND ----------

# MAGIC %sh
# MAGIC echo "4. Offline/restricted runtime: tools already exist in the image"
# MAGIC jq --version
# MAGIC rg --version | head -1
# MAGIC duckdb --version

# COMMAND ----------

# MAGIC %sh
# MAGIC echo "5. CI/CD for the runtime: check demo runtime assets"
# MAGIC test -f /opt/demo/hello.txt
# MAGIC test -x /usr/local/bin/dqcheck
# MAGIC test -x /usr/local/bin/duckdb
# MAGIC echo "Runtime smoke checks passed"

# COMMAND ----------

# MAGIC %sh
# MAGIC echo "6. Legacy/system integration: fake internal CLI"
# MAGIC dqcheck scan --input /tmp/duckdb_demo/orders --output /tmp/dq_report.json
# MAGIC cat /tmp/dq_report.json | jq .

# COMMAND ----------

report = spark.read.json("file:/tmp/dq_report.json")
display(report)

# COMMAND ----------

# MAGIC %sh
# MAGIC echo "7. Enterprise certificates installed once"
# MAGIC ls -l /usr/local/share/ca-certificates/company-root-ca.crt
# MAGIC grep -n "BEGIN CERTIFICATE" /usr/local/share/ca-certificates/company-root-ca.crt

# COMMAND ----------

print("8. Internal wheel package")
from company_quality_rules import validate_table_name, runtime_policy

print(runtime_policy())
print(validate_table_name("customer_orders"))
print(validate_table_name("Customer Orders"))

# COMMAND ----------

# MAGIC %sh
# MAGIC echo "9. Enterprise database client tool"
# MAGIC psql --version
# MAGIC echo "Credentials are not baked into the image. Only the client/runtime is."
