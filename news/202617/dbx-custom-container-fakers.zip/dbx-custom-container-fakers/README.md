# Databricks Custom Container Fakers

Fake-but-runnable assets for an article/demo about Databricks custom containers beyond `pip install`.

## Included assets

- `Dockerfile` — one demo image covering the selected use cases.
- `hello.txt` — simple smoke test file.
- `dist/company_quality_rules-0.1.0-py3-none-any.whl` — real fake Python wheel.
- `certs/company-root-ca.crt` — real self-signed fake root CA certificate.
- `bin/dqcheck` — fake internal CLI tool.
- `sample_data/orders.csv` — tiny input file for DuckDB and dqcheck examples.
- `notebooks/databricks_smoke_tests.py` — notebook cells as plain Python / shell snippets.
- `article_snippets/10_points_with_examples.md` — article-ready points with practical examples.

## Build locally

```bash
docker buildx build \
  --platform linux/amd64 \
  -t hdudek/dbx-custom-container-fakers:0.1 \
  --load .
```

## Local smoke tests

```bash
docker run --rm hdudek/dbx-custom-container-fakers:0.1 cat /opt/demo/hello.txt
```

```bash
docker run --rm hdudek/dbx-custom-container-fakers:0.1 duckdb -c "select 42 as answer, current_date as run_date;"
```

```bash
docker run --rm hdudek/dbx-custom-container-fakers:0.1 dqcheck --version
```

```bash
docker run --rm hdudek/dbx-custom-container-fakers:0.1 \
  dqcheck scan --input /opt/demo/orders.csv --output /tmp/dq_report.json
```

```bash
docker run --rm hdudek/dbx-custom-container-fakers:0.1 \
  /databricks/python3/bin/python -c "from company_quality_rules import validate_table_name; print(validate_table_name('customer_orders'))"
```

## Push

```bash
docker push hdudek/dbx-custom-container-fakers:0.1
```

## Use in Databricks

Attach the image to dedicated compute:

```text
hdudek/dbx-custom-container-fakers:0.1
```

Then run the notebook snippets from `notebooks/databricks_smoke_tests.py`.
