__version__ = "0.1.0"

import re
from datetime import datetime, timezone

def validate_table_name(name: str) -> dict:
    """Fake internal quality rule: table names must be lowercase snake_case."""
    pattern = r"^[a-z][a-z0-9_]*$"
    passed = bool(re.match(pattern, name or ""))
    return {
        "rule": "TABLE_NAME_SNAKE_CASE",
        "input": name,
        "passed": passed,
        "message": "OK" if passed else "Table name must be lowercase snake_case and start with a letter.",
        "checked_at_utc": datetime.now(timezone.utc).isoformat()
    }

def runtime_policy() -> dict:
    """Fake runtime policy embedded in the internal package."""
    return {
        "runtime_owner": "data-platform",
        "approved_runtime": True,
        "package": "company_quality_rules",
        "version": __version__
    }
