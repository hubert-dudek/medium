# myrestdatasource/__init__.py
from .rest_datasource import MyRestDataSource